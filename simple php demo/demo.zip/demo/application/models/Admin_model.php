<?php
/**
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/
class Admin_model extends CI_Model {

    public function login($email, $password){
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $qry = $this->db->get('admin');         
        if($qry->num_rows()===1){
            return $qry->row();
        }
        return false;
    }

   

   
    function get_all(){
      
        $this->db->order_by('std_id', 'DESC');
        $qry = $this->db->get('std_data');   
         return $qry->result(); 
       }
       public function get_all_Grade(){
        $this->db->select('grade');
        $qry = $this->db->get('grades');
        return $qry->result();
    }
          public function get_all_Branch(){
        $this->db->select('branch');
        $qry = $this->db->get('branches');
        return $qry->result();
    }
        
	public function save($data){      
        $this->db->insert('std_data', $data);        
        if($this->db->insert_id()){
            return true;
        }
        return false;
	  }
	  public function delete($data){
        $this->db->where('std_id', $data);
        $this->db->delete('std_data');
        if ( $this->db->affected_rows() ) {
            return true;
        }
        return false;
    }
    public function get_data($std_id){
        $this->db->where('std_id', $std_id);
        $qry = $this->db->get('std_data');
        return $qry->row();
    }
    public function update( $data, $std_id ) {
        $this->db->where('std_id', $std_id);
        $this->db->update( 'std_data', $data );         
        if ( $this->db->affected_rows() ) {
            return true;
        }
        return false;
    }
    


    public function showss($branch){
        $this->db->where('branch', $branch);
        $qry = $this->db->get('std_data');
     return $qry->result();
    }
}
