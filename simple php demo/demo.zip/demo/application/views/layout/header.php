
<!DOCTYPE html>
<html lang="en">
<!--
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/-->
    

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel=icon href="<?php echo base_url('assets/images/favicon.png') ?>" sizes="16x16" type="image/png">
        <title>test</title>

        <!-- core JavaScript-->
        <script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js') ?>"></script>

        
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url('assets/vendor/fontawesome-free/css/all.min.css') ?>" rel="stylesheet"
              type="text/css">

        <!-- Page level plugin CSS-->
        <link href="<?php echo base_url('assets/vendor/datatables/dataTables.bootstrap4.css') ?>" rel="stylesheet">

        <!-- Custom styles for this template-->        
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
        <link href="<?php echo base_url('assets/css/sb-admin.css') ?>" rel="stylesheet">
        
    

    <body id="page-top">

        <nav class="navbar navbar-expand navbar-dark bg-dark sticky-top">

            <a class="navbar-brand" href="<?php echo base_url() ?>"><img src="<?php echo base_url('assets/images/logo.png') ?>" width="50%"></a>

      


 
            <!-- Navbar to left sunday16-8 -->
            <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">

            </form>

                </li>

                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-user-circle fa-fw"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="<?php echo base_url('#') ?>">Settings</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo base_url('admin/logout') ?>">Logout</a>
                    </div>
                </li>
            </ul>

        </nav>

        <div id="wrapper">

            <!-- Sidebar -->
            <ul class="sidebar navbar-nav">
                <li class="nav-item <?php
if ($this->uri->segment(1) == "dashboard") {
    echo 'active';
}
?>">
                    <a class="nav-link" href="<?php echo base_url('dashboard') ?>">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>


           
   
                    <li class="nav-item <?php
                    if ($this->uri->segment(1) == "dashboard/add") {
                        echo 'active';
                    }
    ?>">
                        <a class="nav-link" href="<?php echo base_url('dashboard/add') ?>">
                            <i class="fa fa-desktop"></i>
                            <span>Student Registeration</span></a>
                    </li>

                    <li class="nav-item <?php
                if ($this->uri->segment(1) == "dashboard/branch") {
                    echo 'active';
                }
    ?>">
                        <a class="nav-link" href="<?php echo base_url('dashboard/branch') ?>">
                            <i class="fa fa-tasks"></i>
                            <span>Studant Branch Wise Details</span></a>
                    </li>


                      </ul>
            <div id="content-wrapper">
                <div class="container-fluid">
