          <div class="card mb-3">
          <div class="card-header">
            <span class="h4">404</span>
            
        </div>
          <div class="card-body">
            
          <h1 class="display-1 ">404</h1>
        <p class="lead">Page not found. You can
          <a href="javascript:history.back()">go back</a>
          to the previous page, or
          <a href="<?php echo base_url('dashboard')?>">return home</a>.</p>

          </div>
          
        </div>

        