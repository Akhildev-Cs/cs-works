<!--
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/-->
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table pr-3"></i><span class="h4">ADD STUDENT</span>
        <a class="btn btn-primary float-right" href="<?php echo base_url('dashboard') ?>">Back</a>
    </div>
    <div class="card-body">
	<form method="post" action="<?php echo base_url('dashboard/save') ?>"  autocomplete="off">
           
           
	<div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Student ID</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" name="std_id" value="<?php echo set_value('std_id'); ?>" >
                    <small class="form-text text-danger"><?php echo form_error('std_id'); ?></small>
				</div> </div> 
				<div class="form-group row">
				<label for="inputPassword" class="col-sm-2 col-form-label">First Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="first_name" value="<?php echo set_value('first_name'); ?>" >
					<small class="form-text text-danger"><?php echo form_error('first_name'); ?></small>
                </div></div>
				<div class="form-group row">
			<label for="inputPassword" class="col-sm-2 col-form-label">Last Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="last_name" value="<?php echo set_value('last_name'); ?>" >
					<small class="form-text text-danger"><?php echo form_error('last_name'); ?></small>
                </div>
			</div>
			
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
				<input type="email" class="form-control" name="email" value="<?php echo set_value('email'); ?>" >
                    <small class="form-text text-danger"><?php echo form_error('email'); ?></small>
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Grade</label>
                <div class="col-sm-10">
                    <select class="form-control " name="grade">
                        <option value=" " selected="">Select Grade</option> 
             <?php foreach($grade as $grade):?>
             <option value="<?php echo $grade->grade?>"><?php echo $grade->grade?></option> 
             <?php endforeach;?> 
          </select>
                    <small class="form-text text-danger"><?php echo form_error('grade'); ?></small>
                </div>
            </div>

			<div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Branch</label>
                <div class="col-sm-10">
                    <select class="form-control" name="branch">
                        <option value=" " selected="">Select Branch</option> 
             <?php foreach($branch as $branch):?>
             <option value="<?php echo $branch->branch?>"><?php echo $branch->branch?></option> 
             <?php endforeach;?> 
          </select>
                    <small class="form-text text-danger"><?php echo form_error('branch'); ?></small>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Date of joining</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="date" value="<?php echo set_value('date'); ?>" >
                    <small class="form-text text-danger"><?php echo form_error('date'); ?></small>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </div>

        </form>

    </div>

</div>


