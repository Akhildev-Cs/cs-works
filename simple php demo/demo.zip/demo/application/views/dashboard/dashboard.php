<!--
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/-->
<div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table pr-3"></i><span class="h4">Student details </span>
            <a class="btn btn-primary float-right" href="<?php echo base_url('dashboard/add')?>">Add New</a>
        </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>S:NO</th><th>Studant ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
										<th>email</th>      
										<th>Grade</th>      
										<th>branch</th>      
										<th>date of joining</th>                                          
                    <th>Action</th>
                  </tr>
                </thead>
               
                <tbody>
                  <?php $i =1;?>
                    <?php foreach($std_data as $row):?>
                      <tr>
                      <td><?php echo $i++ ?></td>
                      <td><?php echo $row->std_id?></td>
                      <td><?php echo $row->first_name?></td>
                      <td><?php echo $row->last_name?></td>
											<td><?php echo $row->email?></td>
											<td><?php echo $row->grade?></td>
											<td><?php echo $row->branch?></td>
											<td><?php echo $row->doj?></td>
                      <td>
                    <a class="btn" href="<?php echo base_url('dashboard/edit/'.$row->std_id)?>" title="Edit"><i class="fa fa-edit"></i></a>
                    <a class="btn" href="" onclick="confirm_delete('<?php echo base_url('dashboard/delete/'.$row->std_id)?>')" data-toggle="modal" data-target="#myModal" title="Delete"><i class="fa fa-trash"></i></a>
                    </td> 
                      </tr>
                      <?php endforeach?>
                </tbody>
              </table>
            </div>
          </div>          
        </div>


 <!-- delete modal -->
        <div id="myModal" class="modal fade">
	<div class="modal-dialog modal-confirm modal-dialog-centered">
		<div class="modal-content">
			<div class="modal-header">
				<div class="icon-box">          
          <i class="fa fa-times" aria-hidden="true"></i>
        </div>
        	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <!-- <div class="row">	 -->
        <h4 class="modal-title">Are you sure?</h4>	
                    <!-- </div> -->
			<div class="modal-body">
				<p>Do you really want to delete these records? This process cannot be undone.</p>
			</div>
			<div class="modal-footer">        
				<a class="btn btn-info" data-dismiss="modal">Cancel</a>
        <a class="btn btn-danger" id="delete" href="">Delete</a>                  
			</div>
		</div>
	</div>
</div>  

<script type="text/javascript">
        $(document).ready(function() {
  $('#dataTable').DataTable();  
});

function confirm_delete(url)
    	{
        console.log(url);
    		jQuery('#myModal').modal('show', {backdrop: 'static',keyboard :false});    		
    		document.getElementById('delete').setAttribute("href" , url );
    		document.getElementById('delete').focus();
    	}
        </script>
