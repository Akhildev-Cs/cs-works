<!--
* Author:  Akhildev cs
* Created:   18.08.2020
* 
**/-->
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table pr-3"></i><span class="h4">ADD STUDENT</span>
        <a class="btn btn-primary float-right" href="<?php echo base_url('dashboard') ?>">Back</a>
    </div>
    <div class="card-body">
	<form method="post" action="<?php echo base_url('dashboard/branches') ?>"  autocomplete="off">
           
    <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Branch</label>
                <div class="col-sm-10">
                    <select class="form-control" name="branch">
                        <option value=" " selected="">Select Branch</option> 
             <?php foreach($branch as $branch):?>
             <option value="<?php echo $branch->branch?>"><?php echo $branch->branch?></option> 
             <?php endforeach;?> 
          </select>
                    <small class="form-text text-danger"><?php echo form_error('branch'); ?></small>
                </div>
            </div>

            
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </div>

        </form>

    </div>

</div>

