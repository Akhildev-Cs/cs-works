<!--
* Author:  Akhildev cs
* Created:   17.08.2020
* 
**/-->
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table pr-3"></i><span class="h4">UPDATE STUDENT DETAILS</span>
        <a class="btn btn-primary float-right" href="<?php echo base_url('dashboard')?>">Back</a>
    </div>
    <div class="card-body">

        <form method="post"  action="<?php echo base_url('dashboard/update')?>" enctype="multipart/form-data"
            autocomplete="off">
            
                <input type="hidden" name="std_id"  value="<?php echo $data->std_id ?>">
                
               
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">First Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="first_name" value="<?php echo set_value('first_name', isset($data->first_name) ? $data->first_name : ''); ?>">
                    <small class="form-text text-danger"><?php echo form_error('first_name'); ?></small>
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Last Name</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="last_name" value="<?php echo set_value('last_name', isset($data->last_name) ? $data->last_name : ''); ?>">
                    <small class="form-text text-danger"><?php echo form_error('last_name'); ?></small>
                </div>
            </div>

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" name="email" value="<?php echo set_value('email', isset($data->email) ? $data->email : ''); ?>">
                    <small class="form-text text-danger"><?php echo form_error('email'); ?></small>
                </div>
            </div>
            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Grade</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="grade" value="<?php echo set_value('grade', isset($data->grade) ? $data->grade : ''); ?>">
                    <small class="form-text text-danger"><?php echo form_error('grade'); ?></small>
                </div>
            </div>
            
	

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Date of joining</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="doj" value="<?php echo set_value('doj', isset($data->doj) ? $data->doj : ''); ?>" >
                    <small class="form-text text-danger"><?php echo form_error('ddoj'); ?></small>
                </div>
            </div>
         

            <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </div>


        </form>

    </div>

</div>

<script>
        $(document).ready(function(){
          var csrf_token = '';
          $('#productcategory_id').change(function(){
            if(csrf_token == ''){
               csrf_token = "<?php echo $this->security->get_csrf_hash();?>";
            }           
            
              var productcategory_id = $(this).val();              
                $.ajax({
                  method:"POST",
                  url:"<?php echo base_url('ajax/productsubcategory')?>",
                  data:{csrf_hykon:csrf_token, productcategory_id:productcategory_id},
                  dataType:"json",
                  success:function(response){                    
                    if(response.csrf_token){
                      csrf_token = response.csrf_token;
                      $('#htoken').val(csrf_token);
                    }
                    $('#productsubcategory_id').html(response.data);
                  }
                });   
                          
              
          });
        });
        </script>
