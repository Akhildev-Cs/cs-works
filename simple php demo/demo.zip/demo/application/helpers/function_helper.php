<?php
/**
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/
function isAdmin(){
    $ci =& get_instance();
    $role = $ci->session->userdata('user_role');
    if($role == '0'){
        return true;
    }
    return false;
}

function Save($table,$data){
    $ci =& get_instance();
    $ci->load->model('Admin_model', 'admin');
    return $ci->admin->save($table,$data);
}

function Delete($table,$id){
    $ci =& get_instance();
    $ci->load->model('Admin_model', 'admin');
    return $ci->admin->delete($table,$id);
}
