<?php
/**
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/
defined( 'BASEPATH' ) OR exit( 'No direct script access allowed' );

class Dashboard extends CI_Controller {

    public function __construct()
 {
        parent::__construct();
        $this->load->model( 'Admin_model', 'admin' );
        $this->controller = strtolower(__CLASS__);
    }

    public function index()
    {        $data['std_data'] = $this->admin->get_all(); 
            $this->layout->template(TEMPLATE_ADMIN)->show($this->controller . '/dashboard', $data );
  

    }


    public function add() {
		$data['grade'] = $this->admin->get_all_Grade();
		$data['branch'] = $this->admin->get_all_Branch();
        $this->layout->template( TEMPLATE_ADMIN )->show( $this->controller .'/'.__FUNCTION__, $data );

    }
    public function save() {
        if ( $this->input->post() ) {

			$this->form_validation->set_rules( 'std_id', 'std_id',  'required|numeric' );  
			 $this->form_validation->set_rules( 'last_name', 'last_name',  'required' ); 
			  $this->form_validation->set_rules( 'first_name', 'first_name',  'required' ); 
			  $this->form_validation->set_rules( 'email', 'email', 'required' ); 
			$this->form_validation->set_rules( 'grade', 'grade', 'required' );  
			  $this->form_validation->set_rules( 'branch', 'branch', 'required' );           
            $this->form_validation->set_rules( 'date', 'date', 'required' );
            

            if ( $this->form_validation->run() == FALSE )
 {              
				$data['std_id'] = $this->admin->get_all();
				
                $this->layout->template( TEMPLATE_ADMIN )->show( $this->controller .'/add', $data );
            } else {  
                
                $std_id= $this->input->post( 'std_id' ) ;         
               
				$data['std_id'] = $std_id;  
				$data['first_name'] = $this->input->post( 'first_name' ) ;
				$data['last_name'] = $this->input->post( 'last_name' ) ;
				$data['email'] = $this->input->post( 'email' ) ;
				$data['grade'] = $this->input->post( 'grade' ) ;
				$data['branch'] = $this->input->post( 'branch' ) ;
                
                $data['doj'] = $this->input->post('date') ;
             

                if ( $this->admin->save( $data ) ) {
                    $this->session->set_flashdata( 'success', ' inserted successfully' );
                    redirect( $this->controller );
                } else {
                    $this->session->set_flashdata( 'error', ' insertion failed!. please try again' );
                    redirect( $this->controller.'/add' );
                }

            }
        }
    }

public function edit($std_id){
    $data['data'] = $this->admin->get_data( $std_id );                
    $this->layout->template( TEMPLATE_ADMIN )->show( $this->controller .'/'.__FUNCTION__, $data );
}

    public function update()
 {       

        if ( $this->input->post() ) {

            $std_id = $this->input->post( 'std_id' );
            
            $this->form_validation->set_rules( 'first_name', 'first_name', 'required' );
            $this->form_validation->set_rules( 'last_name', 'last_name', 'required' );         
            $this->form_validation->set_rules( 'email', 'email', 'required' );
           
            $this->form_validation->set_rules( 'grade', 'grade', 'required' );         
            $this->form_validation->set_rules( 'doj', 'doj', 'required' );
           
            
            if ( $this->form_validation->run() == FALSE )
 {               
           
                $data['data'] = $this->admin->get_data( $std_id );              
                $this->layout->template( TEMPLATE_ADMIN )->show( $this->controller .'/edit', $data );

            } else {
                
                $data['first_name'] = $this->input->post( 'first_name' ) ; 
                $data['last_name'] = $this->input->post( 'last_name' ) ;               
                $data['email'] = $this->input->post( 'email' ) ; 
                $data['grade'] = $this->input->post( 'grade' ) ;
                 $data['doj'] = $this->input->post( 'doj' ) ;              
               

                if ( $this->admin->update( $data, $std_id ) ) {

                    $this->session->set_flashdata( 'success', '  updated successfully.' );
                    redirect( $this->controller );
                } else {                    
                        $this->session->set_flashdata( 'info', 'no changes made in data' );
                        redirect( $this->controller );
                }
            }
        }       

    }

    public function delete( $std_id ) {
        if ( $this->admin->delete( $std_id ) ) {
           
            $this->session->set_flashdata( 'success', ' deleted successfully.' );
            redirect( $this->controller );
        } else {
            $this->session->set_flashdata( 'error', ' deletion failed!' );
            redirect( $this->controller );
        }
    }



public function branch(){
    $data['branch'] = $this->admin->get_all_Branch();
        $this->layout->template( TEMPLATE_ADMIN )->show( $this->controller .'/branch', $data );
}
public function branches(){
   
    if ( $this->input->post() ) {

        $branch = $this->input->post( 'branch' ) ;
       // $data['std_id'] = $this->admin->get_all();  
                   
                    if ( $this->admin->showss( $branch) ) {
                        $branch = $this->admin->showss($branch);                
				
					if($branch){
		
							$data['branches']=$branch;
							
					     
					$this->layout->template( TEMPLATE_ADMIN )->show( 'branches/branches' ,$data );
				}
                        $this->session->set_flashdata( 'success' );
                        
                    } else {                    
                            $this->session->set_flashdata( 'faild' );
                            redirect( $this->controller );
                    }
                }
            }       
    
 }
    
