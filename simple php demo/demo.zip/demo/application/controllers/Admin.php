<?php
/**
* Author:  Akhildev cs
* Created:   16.08.2020
* 
**/

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


    public function __construct()
        {
                parent::__construct();
                $this->load->model('Admin_model', 'admin');       
           
        }
	
	public function index()
	{
        if(!isAdmin() ){
        
        if($this->input->post()){
            $email = $this->input->post('email');
            $password = $this->input->post('password');            
            if($email==='' || $password===''){
                $this->session->set_flashdata('error', 'Please fill all fields!');
                redirect(current_url());
            }

            $user_data = $this->admin->login($email,md5($password)); 
            if($user_data){
                $newdata = array( 
                    'user_id' => $user_data->id,  
                    'name'     => $user_data->name,                 
                    'email'     => $user_data->email,
                    'user_role' => $user_data->user_role,
                    'logged_in' => TRUE
            );            
                $this->session->set_userdata($newdata);
                $this->session->set_flashdata('success', 'Welcome to admin area');
                redirect('dashboard');
            }else{
                $this->session->set_flashdata('error', 'Invalid login details!');
                redirect(current_url());
            }
        }
        $this->load->view('login/login');
    }else{
        redirect('dashboard');
    }
        
    }
    


    public function logout(){
        $this->session->sess_destroy();
        redirect(base_url());
    }
}
